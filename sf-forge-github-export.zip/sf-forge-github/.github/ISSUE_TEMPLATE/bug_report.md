---
name: Bug report
about: Something broken in SF Forge
title: '[BUG] '
labels: bug
---

**SF Forge version:** v5.1.1
**Chrome version:**
**Salesforce org type:** Production / Sandbox / Developer Edition

**Which tool:** Dashboard / Inspector / Metadata Studio / etc.

**What happened:**

**Steps to reproduce:**
1.
2.
3.

**Error message (paste from toast or DevTools console):**

**Expected behavior:**
