---
name: Feature request
about: Suggest a new SF Forge capability
title: '[FEATURE] '
labels: enhancement
---

**Which tool area does this relate to?**

**What problem does it solve?**

**Describe the feature:**

**Salesforce API / endpoint involved (if known):**
